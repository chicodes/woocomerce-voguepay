<?php

/*
  Plugin Name: Voguepay WooCommerce Payment Plugin
  Plugin URI: http://https://github.com/chicodes/
  Description: Voguepay Payment Processing
  Version: 1.0
  Author: Akagha Chinaka
  Author URI: https://web.facebook.com/akaghachinaka1
 */

if (!defined('ABSPATH')) {
    exit;
}
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}

add_action('plugins_loaded', 'woocommerce_voguepay_init', 0);

function woocommerce_voguepay_init() {
    if (!class_exists('WC_Payment_Gateway'))
        return;

    class WC_Voguepay extends WC_Payment_Gateway {

        public function __construct() {
            $this->voguepay_errors = new WP_Error();

            $this->id = 'voguepay';
            $this->medthod_title = 'VoguepayPayment';
            $this->icon = apply_filters('woocommerce_voguepay_icon', plugins_url('assets/images/logo.png', __FILE__));
            $this->has_fields = false;

            $this->init_form_fields();
            $this->init_settings();


            $this->vogue_pay_enviroment_status = $this->settings['vogue_pay_enviroment_status'];
            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->voguepay_mert_id = ($this->vogue_pay_enviroment_status=='yes')?"demo":$this->settings['voguepay_mert_id'];
            $this->voguepay_mert_ref = $this->setings['voguepay_mert_ref'];
            $this->voguepay_store_id = $this->settings['voguepay_store_id'];
            $this->voguepay_tranx_curr = $this->settings['voguepay_tranx_curr'];
            $this->hashkey = $this->settings['hashkey'];
            $this->voguepay_tranx_query_url = $this->settings['voguepay_tranx_query_url'];
            


            $this->posturl = 'https://voguepay.com/pay/';
            $this->geturl = 'https://voguepay.com/pay/';

            $this->msg['message'] = "";
            $this->msg['class'] = "";

            if (isset($_POST["transaction_id"])) {
                $this->check_voguepay_response();
            }

            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array(&$this, 'process_admin_options'));
            }

            add_action('woocommerce_receipt_voguepay', array(&$this, 'receipt_page'));
        }

        function receipt_page($order) {
            global $woocommerce;
            $items = $woocommerce->cart->get_cart();
            $item_rows = "";
            $currency = get_woocommerce_currency_symbol();
            $css = "<style>
                    .label-info{
                        background-color: green;
                        color: #f4f4f4;
                        padding: 5px;
                    }
                    tbody tr td { border-bottom: 1px solid; }
                    tbody tr{
                        font-size:14px;
                    }
                    thead{
                        font-size:16px;
                    }
                    tbody tr td{
                        padding: 10px 0px;
                    }tr:nth-child(even) {
                        background-color: #f4f4f4;
                    }
                    tfoot tr td:nth-child(1){
                        font-weight: bold;
                        font-size: 22px;
                        padding: 10px 0px 0px 10px;
                    }
                    </style>";
            echo $css;
            $price_total = 0;

            $order_data = new WC_Order($order);
            $shipping = $order_data->get_shipping_method();
            $shipping_rate = $order_data->get_total_shipping();
 
            foreach ($items as $item => $values) {
                $_product = $values['data']->post;
                $price = get_post_meta($values['product_id'], '_price', true) * $values['quantity'];
                $price_total += $price;
                $item_rows .= '<tr><td>' . $_product->post_title . '</td><td>' . $values['quantity'] . '</td><td>' . $price . '</td> </tr>'; 
            }
            $item_rows .= "<tr><td><b><i>Sub Total</i></b></td><td></td><td>" . $price_total . "</td></tr>";
            if ($shipping && $shipping <> "") {
                $item_rows .= "<tr><td><b><i>Shipping(" . $shipping
                        . ")</i></b></td><td></td><td>" . $shipping_rate
                        . "</td></tr>";
            }
            if ($shipping_rate > 0) {
                $price_total += $shipping_rate;
            }
            $confirmation_table = '<p><span class="label-info">Please review your order then click on "Pay via voguepay" button</span></p>
                                    <br><h2>Your Order</h2>
                                    <table><thead><tr><th>Product</th><th>Qty</th><th>Amount(' . trim($currency) . ')</th></tr><thead>
                                    <tbody>' . $item_rows . '</tbody>
                                    <tfoot><tr><td><b>Grand Total</b></td><td></td><td><b>' . $currency . $price_total .
                    '</b></td></tr></tfoot></table>';

            echo $confirmation_table;
            echo $this->generate_voguepay_form($order);
        }

        public function generate_voguepay_items_args(){
            global $woocommerce;
            $items = $woocommerce->cart->get_cart();

            $voguepay_items_purchased = array();
            $voguepay_item_count = 0;
            foreach ($items as $item => $values) {
                $_product = $values['data']->post;
                $price = get_post_meta($values['product_id'], '_price', true) * $values['quantity'];
                $voguepay_item_purchased = array();
                $voguepay_item_purchased["item_".++$voguepay_item_count] = $_product->post_title;
                $voguepay_item_purchased["description_".$voguepay_item_count] = $_product->post_title;
                $voguepay_item_purchased["price_".$voguepay_item_count] = $price;
                $voguepay_items_purchased[] = $voguepay_item_purchased;
            }

            return $voguepay_items_purchased;
        }

        public function generate_voguepay_form($order_id) {
            global $woocommerce;

            $order = new WC_Order($order_id);
            $txnid = $order_id . '_' . date("ymds");

            $redirect_url = $woocommerce->cart->get_checkout_url();
            $voguepay_cust_id = $order->billing_email;

            $voguepay_hash = $this->voguepay_mert_id . $txnid . $order->order_total * 100 . $this->voguepay_tranx_curr
                    . $voguepay_cust_id . $redirect_url . $this->hashkey;
            $hash = hash('sha512', $voguepay_hash);

            $voguepay_args = array(
                'v_merchant_id' => $this->voguepay_mert_id,
                'merchant_ref'=>$this->voguepay_mert_ref.'#'.$txnid,
                'memo'=> '',

                //'developer_code' => $hash,
                //'store_id' => $this->voguepay_store_id,
                'total' => $order->order_total * 100, 
 
                'notify_url' => $redirect_url,
                'success_url'  => $redirect_url,
                'fail_url'  => $redirect_url,

                'cur' => $this->voguepay_tranx_curr,
                'voguepay_cust_id' => $voguepay_cust_id,   
                'voguepay_echo_data' => $order_id . ";" . $hash
            );

            $voguepay_args = array_merge($voguepay_args, $this->generate_voguepay_items_args());

            $voguepay_args_array = array();
            foreach ($voguepay_args as $key => $value) {
                $voguepay_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
            }
            return '<form action="' . $this->posturl . '" method="post" id="voguepay_payment_form">
            ' . implode('', $voguepay_args_array) . '
            <input type="submit" class="button-alt" id="submit_voguepay_payment_form" value="' . __('Pay via voguepay', 'voguepay') . '" /> <a class="button cancel" href="' . $order->get_cancel_order_url() . '">' . __('Cancel order &amp; restore cart', 'voguepay') . '</a>
            <script type="text/javascript">
function processVoguePayJSPayment(){
jQuery("body").block(
        {
            message: "<img src=\"' . plugins_url('assets/images/ajax-loader.gif', __FILE__) . '\" alt=\"redirecting...\" style=\"float:left; margin-right: 10px;\" />' . __('Thank you for your order. We are now redirecting you to Payment Gateway to make payment.', 'voguepay') . '",
                overlayCSS:
        {
            background: "#fff",
                opacity: 0.6
    },
    css: {
        padding:        20,
            textAlign:      "center",
            color:          "#555",
            border:         "3px solid #aaa",
            backgroundColor:"#fff",
            cursor:         "wait",
            lineHeight:"32px"
    }
    });
    jQuery("#voguepay_payment_form").submit();
    }
    jQuery("#submit_voguepay_payment_form").click(function (e) {
        e.preventDefault();
        processVoguePayJSPayment();
    });
</script>
            </form>';
        }

        function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'voguepay'),
                    'type' => 'checkbox',
                    'label' => __('Enable voguepay Payment Module.', 'voguepay'),
                    'default' => 'no'),
                'title' => array(
                    'title' => __('Title:', 'voguepay'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'voguepay'),
                    'default' => __('voguepay Payment', 'voguepay')),
                'description' => array(
                    'title' => __('Description:', 'voguepay'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'voguepay'),
                    'default' => __('voguepay is a voguepay’s payment gateway which facilitates merchant collection from their website. It offers the options for local and international credit/debit cards, Bank Transfers from any Nigerian Bank as well as Mobile Money wallets and is constantly being extended to offer more payment options to your clients.', 'voguepay')),
                'voguepay_mert_id' => array(
                    'title' => __('voguepay Merchant ID', 'voguepay'),
                    'type' => 'text',
                    'description' => __('This is the voguepay-wide unique identifier of merchant, assigned by voguepay and communicated to merchant by voguepay after merchant registration.')),
                'voguepay_mert_ref' => array(
                    'title' => __('voguepay Merchant REF', 'voguepay'),
                    'type' => 'text',
                    'description' => __('This value will be returned with the confirmation results from the confirmation api. VoguePay doesnt need this value, it is used by the merchant to store any data he wishess to retrieve later with the transaction details.')),
                'voguepay_store_id' => array(
                    'title' => __('voguepay Store Id', 'voguepay'),
                    'type' => 'text',
                    'description' => __('A unique store identifier which identifies a particular store a transaction was made.')),
                'hashkey' => array(
                    'title' => __('Hash Key', 'voguepay'),
                    'type' => 'text',
                    'description' => __('Please note that the hash key will be provided by voguepay upon completing registration."')),
                'voguepay_tranx_curr' => array(
                    'title' => __('Currency', 'voguepay'),
                    'type' => 'text',
                    'description' => __('This parameter represents the ISO currency code representing the currency in which the transaction is been carried out. Acceptable values Naira  - (566). USD  - (840)"')),

                'voguepay_tranx_query_url' => array(
                    'title' => __('URL to query transaction status', 'voguepay'),
                    'type' => 'text',
                    'description' => __('This parameter represents URL to get the status of the transaction')),

                'vogue_pay_enviroment_status' => array(
                    'title' => __('Enable/Disable Demo', 'voguepay'),
                    'type' => 'checkbox',
                    'label' => __('Enable demo.', 'voguepay'),
                    'default' => 'no')
            );
        }

        public function admin_options() {
            echo '<h3>' . __('voguepay Payment Gateway', 'voguepay') . '</h3>';
            echo '<p>' . __('voguepay is most popular payment voguepay for online shopping in Nigeria') . '</p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
            wp_enqueue_script('voguepayvoguepay_admin_option_js', plugin_dir_url(__FILE__) . 'assets/js/settings.js', array('jquery'), '1.0.1');
        }

        function payment_fields() {
            if ($this->description)
                echo wpautop(wptexturize($this->description));
        }

        function process_payment($order_id) {
            global $woocommerce;
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => add_query_arg(
                        'order', $order->id, add_query_arg(
                                'key', $order->order_key, get_permalink(get_option('woocommerce_pay_page_id'))
                        )
                )
            );
        }

        function showMessage($content) {
            return '<div class="box ' . $this->msg['class'] . '-box">' . $this->msg['message'] . '</div>' . $content;
        }

        function get_pages($title = false, $indent = true) {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title)
                $page_list[] = $title;
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }

        function check_voguepay_response() {
            global $woocommerce;
            $voguepay_echo_data = $_POST["voguepay_echo_data"];
            $data = explode(";", $voguepay_echo_data);
            $wc_order_id = $data[0];
            $order = new WC_Order($wc_order_id);
            $tranxid = $_POST["transaction_id"];

            try {
                $isDemo = ($this->vogue_pay_enviroment_status == 'yes')?"&demo=true":"";
                $status_responce = file_get_contents($this->voguepay_tranx_query_url.'?v_transaction_id='.$tranxid.'&type=json'.$isDemo);
                $transaction_details= json_decode($status_responce);

                if ($transaction_details->status === "Failed") {
                    #payment cancelled
                    $respond_desc = ""; // $_POST["voguepay_tranx_status_msg"];
                    $message_resp = "Your transaction was not successful." .
                            "<br>Reason: " . $respond_desc .
                            "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('voguepay payment failed: ' . $respond_desc);
                    $order->update_status('cancelled');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                }
                else if ($transaction_details->status === "Pending") {
                    #payment pending
                    $respond_desc = ""; // $_POST["voguepay_tranx_status_msg"];
                    $message_resp = "Your transaction is pending." .
                            "<br>Reason: " . $respond_desc .
                            "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('voguepay payment is pending: ' . $respond_desc);
                    $order->update_status('pending');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                } 
                else if($transaction_details->status === "Approved") {
                    wc_print_notices();
                    $mert_id = $this->voguepay8_mert_id;
                    $hashkey = $this->hashkey;
                    $my_hash = hash("sha512", $mert_id . $tranxid . $hashkey);
                    
                    #payment successful
                    $respond_desc = ""; // $response_decoded->ResponseDescription;
                    $message_resp = "Approved Successful." .
                        "<br>" . $respond_desc .
                        "<br>Transaction Reference: " . $tranxid;
                    $message_type = "success";
                    $order->payment_complete();
                    $order->update_status('completed');
                    $order->add_order_note('GTPay payment successful: ' . $message_resp);
                    $woocommerce->cart->empty_cart();
                    $redirect_url = $this->get_return_url($order);
                    wc_add_notice($message_resp, "success");
                    
                }
                else{
                    #payment failed
                    $respond_desc = "";// $response_decoded->ResponseDescription;
                    $message_resp = "Your transaction was not successful." .
                        "<br>Reason: " . $respond_desc .
                        "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('Voguepay payment failed: ' . $message_resp);
                    $order->update_status('cancelled');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                }

                $notification_message = array(
                    'message' => $message_resp,
                    'message_type' => $message_type
                );

                wp_redirect(html_entity_decode($redirect_url));
                exit;
            } catch (Exception $e) {
                $order->add_order_note('Error: ' . $e->getMessage());

                wc_add_notice($e->getMessage(), "error");
                $redirect_url = $order->get_cancel_order_url();
                wp_redirect(html_entity_decode($redirect_url));
                exit;
            }
        }

        static function add_voguepay_currency($currencies) {
            $currencies['Naira'] = __('Naira', 'woocommerce');
            $currencies['USD'] = __('US Dollar', 'woocommerce');
            return $currencies;
        }

        static function add_voguepay_currency_symbol($currency_symbol, $currency) {
            switch ($currency) {
                case 'Naira':
                    $currency_symbol = '₦ ';
                    break;
                case 'USD':
                    $currency_symbol = '$ ';
                    break;
            }
            return $currency_symbol;
        }

        static function woocommerce_add_voguepay_gateway($methods) {
            $methods[] = 'WC_VoguePay';
            return $methods;
        }

        // Add settings link on plugin page
        static function woocommerce_add_voguepay_settings_link($links) {
            $settings_link = '<a href="admin.php?page=wc-settings&tab=checkout&section=wc_voguepay">Settings</a>';
            array_unshift($links, $settings_link);
            return $links;
        }

    }

    $plugin = plugin_basename(__FILE__);

    add_filter('woocommerce_currencies', array('WC_VoguePay', 'add_voguepay_currency'));
    add_filter('woocommerce_currency_symbol', array('WC_VoguePay', 'add_voguepay_currency_symbol'), 10, 2);
    add_filter("plugin_action_links_$plugin", array('WC_VoguePay', 'woocommerce_add_voguepay_settings_link'));
    add_filter('woocommerce_payment_gateways', array('WC_VoguePay', 'woocommerce_add_voguepay_gateway'));
}
